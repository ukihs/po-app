
import React, { useEffect, useState } from 'react';
import { auth, db } from '../../lib/firebase';
import { fetchUserRole } from '../../lib/auth';
import { collection, onSnapshot, orderBy, query, where } from 'firebase/firestore';

type Row = {
  id: string;
  orderNo?: number;
  requesterName?: string;
  total?: number;
  status: 'pending' | 'approved' | 'rejected' | 'in_progress' | 'delivered';
  createdAt?: any;
};

export default function OrdersListPage() {
  const [role, setRole] = useState<string>('user');
  const [rows, setRows] = useState<Row[]>([]);
  const [err, setErr] = useState<string>('');

  useEffect(() => {
    const u = auth.currentUser;
    if (!u) return;
    fetchUserRole(u.uid).then(setRole).catch(()=>{});
  }, []);

  useEffect(() => {
    const u = auth.currentUser;
    if (!u) return;
    const q = query(
      collection(db, 'orders'),
      where('status', '==', 'pending'),
      orderBy('createdAt', 'desc')
    );
    const stop = onSnapshot(q, (snap) => {
      const list = snap.docs.map((d) => ({ id: d.id, ...(d.data() as any) })) as Row[];
      setRows(list);
    }, (e) => setErr(e?.message ?? 'โหลดข้อมูลไม่สำเร็จ'));
    return () => stop();
  }, []);

  if (role !== 'supervisor') {
    return <div className="container-nice py-6">หน้านี้สำหรับหัวหน้างาน</div>;
  }

  if (err) return <div className="container-nice py-6"><div className="alert error">{err}</div></div>;

  return (
    <div className="container-nice py-6">
      <h2 className="text-xl font-semibold mb-4">รายการรออนุมัติ</h2>
      <div className="card">
        <div className="card-pad">
          <table className="w-full text-sm">
            <thead className="bg-slate-50/80">
              <tr className="text-left text-slate-600">
                <th className="px-3 py-2 w-24">เลขที่</th>
                <th className="px-3 py-2">ผู้สั่งซื้อ</th>
                <th className="px-3 py-2 w-40">สร้างเมื่อ</th>
                <th className="px-3 py-2 w-32 text-right">ยอดรวม</th>
                <th className="px-3 py-2 w-28">สถานะ</th>
                <th className="px-3 py-2 w-24"></th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {rows.map((r) => (
                <tr key={r.id} className="odd:bg-white even:bg-slate-50/40">
                  <td className="px-3 py-2">{r.orderNo ?? '—'}</td>
                  <td className="px-3 py-2">{r.requesterName || '—'}</td>
                  <td className="px-3 py-2">{r.createdAt?.toDate ? r.createdAt.toDate().toLocaleString('th-TH') : '—'}</td>
                  <td className="px-3 py-2 text-right">{Number(r.total || 0).toLocaleString('th-TH')}</td>
                  <td className="px-3 py-2">{labelStatus(r.status)}</td>
                  <td className="px-3 py-2">
                    <a className="btn btn-primary btn-sm" href={`/orders/${r.id}`}>เปิดดู</a>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function labelStatus(s: Row['status']) {
  switch (s) {
    case 'pending': return 'รออนุมัติ';
    case 'approved': return 'อนุมัติแล้ว';
    case 'rejected': return 'ไม่อนุมัติ';
    case 'in_progress': return 'กำลังจัดซื้อ';
    case 'delivered': return 'รับของแล้ว';
  }
}
