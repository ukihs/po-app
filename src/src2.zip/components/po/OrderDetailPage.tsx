import React, { useEffect, useMemo, useState } from 'react';
import { auth, db } from '../../lib/firebase';
import {
  doc, getDoc, updateDoc, serverTimestamp, addDoc, collection,
} from 'firebase/firestore';

type Order = {
  id: string;
  requesterUid: string;
  requesterName: string;
  date: string;
  items: { description: string; receivedDate?: string | null; quantity: number; amount: number; lineTotal: number }[];
  total: number;
  status: 'pending' | 'approved' | 'rejected' | 'in_progress' | 'delivered';
  orderNo?: number;
  createdAt?: any;
};

async function getUserRole(uid: string): Promise<'supervisor'|'procurement'|'user'> {
  const snap = await getDoc(doc(db, 'users', uid));
  const data = snap.exists() ? (snap.data() as any) : {};
  return (data.role as any) || 'user';
}

async function notify(toUserUid: string, payload: any) {
  await addDoc(collection(db, 'notifications'), {
    toUserUid,
    read: false,
    createdAt: serverTimestamp(),
    ...payload,
  });
}

export default function OrderDetailPage({ id }: { id: string }) {
  const [order, setOrder] = useState<Order | null>(null);
  const [role, setRole] = useState<'supervisor'|'procurement'|'user'>('user');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const canApprove = useMemo(() => role === 'supervisor' && order?.status === 'pending', [role, order]);

  useEffect(() => {
    let alive = true;
    (async () => {
      const u = auth.currentUser;
      if (u) setRole(await getUserRole(u.uid));

      const snap = await getDoc(doc(db, 'orders', id));
      if (!alive) return;
      if (!snap.exists()) {
        setOrder(null);
        setLoading(false);
        return;
      }
      setOrder({ id: snap.id, ...(snap.data() as any) });
      setLoading(false);
    })();
    return () => { alive = false; };
  }, [id]);

  const approve = async (decision: 'approved'|'rejected') => {
    if (!order || !auth.currentUser) return;
    if (!canApprove) return;

    setSaving(true);
    try {
      // 1) อัปเดตสถานะใบสั่งซื้อ
      await updateDoc(doc(db, 'orders', order.id), {
        status: decision,
        approvedAt: serverTimestamp(),
        approvedByUid: auth.currentUser.uid,
        approvedByName: auth.currentUser.displayName || (auth.currentUser.email ?? '').split('@')[0] || 'หัวหน้างาน',
      });

      // 2) แจ้งเตือนผู้ขอซื้อ
      await notify(order.requesterUid, {
        title: decision === 'approved' ? 'ใบสั่งซื้อได้รับอนุมัติ' : 'ใบสั่งซื้อถูกปฏิเสธ',
        message: `ใบสั่งซื้อ #${order.orderNo ?? '-'} โดย ${order.requesterName}`,
        kind: 'approval_result',
        orderId: order.id,
        orderNo: order.orderNo ?? null,
      });

      // 3) ถ้าอนุมัติแล้ว ส่งต่อถึงฝ่ายจัดซื้อ
      if (decision === 'approved') {
        // สมมติระบุ procurementUid ไว้ใน users/{uid} ของหัวหน้างานหรือคอนฟิกส่วนกลาง
        // ที่ง่ายสุด: ใส่ collection users แล้วให้หาคน role == 'procurement'
        // ที่นี่ส่งแบบง่าย: ส่งให้ตัวเองอีกทีหรือหากคุณรู้ uid ของ procurement ให้แทนลงไป
        // await notify('<<procurement-uid>>', { ... });
      }

      // อัปเดต UI
      setOrder((prev) => prev ? { ...prev, status: decision } : prev);
      alert(decision === 'approved' ? 'อนุมัติสำเร็จ' : 'ปฏิเสธสำเร็จ');
    } catch (e: any) {
      console.error(e);
      alert(e?.message ?? 'อัปเดตสถานะไม่สำเร็จ');
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <div className="p-4">กำลังโหลด...</div>;
  if (!order) return <div className="p-4">ไม่พบใบสั่งซื้อ</div>;

  return (
    <div className="container-nice page-narrow py-6 md:py-10">
      <div className="card">
        <div className="card-pad space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl md:text-2xl font-semibold">
              ใบสั่งซื้อ #{order.orderNo ?? '-'}
            </h2>
            <span className="text-sm rounded-full px-3 py-1 bg-slate-100">
              สถานะ: <b>{order.status}</b>
            </span>
          </div>

          <div className="text-sm text-slate-600">
            ผู้สั่งซื้อ: <b>{order.requesterName}</b> &nbsp;|&nbsp; วันที่เอกสาร: {order.date}
          </div>

          <div className="border rounded-2xl overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-slate-50">
                <tr className="text-left text-slate-600">
                  <th className="px-3 py-2">#</th>
                  <th className="px-3 py-2">รายการ</th>
                  <th className="px-3 py-2">วันที่รับ</th>
                  <th className="px-3 py-2">จำนวน</th>
                  <th className="px-3 py-2 text-right">ราคา/หน่วย</th>
                  <th className="px-3 py-2 text-right">รวม</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {order.items?.map((it, i) => (
                  <tr key={i} className="align-top">
                    <td className="px-3 py-2">{i + 1}</td>
                    <td className="px-3 py-2">{it.description}</td>
                    <td className="px-3 py-2">{it.receivedDate || '-'}</td>
                    <td className="px-3 py-2">{it.quantity}</td>
                    <td className="px-3 py-2 text-right">{it.amount.toLocaleString('th-TH')}</td>
                    <td className="px-3 py-2 text-right">{it.lineTotal.toLocaleString('th-TH')}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="flex items-center justify-between">
            <div />
            <div className="text-base">
              รวมเป็นเงิน: <b>{(order.total ?? 0).toLocaleString('th-TH')} บาท</b>
            </div>
          </div>

          {canApprove && (
            <div className="flex gap-3 pt-2">
              <button
                disabled={saving}
                onClick={() => approve('approved')}
                className="btn btn-green px-5 py-2 disabled:opacity-60"
              >
                {saving ? 'กำลังบันทึก...' : 'อนุมัติ'}
              </button>
              <button
                disabled={saving}
                onClick={() => approve('rejected')}
                className="btn btn-red px-5 py-2 disabled:opacity-60"
              >
                ไม่อนุมัติ
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
