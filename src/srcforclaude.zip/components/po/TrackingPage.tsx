import React, { useEffect, useState } from 'react';
import { auth, db } from '../../lib/firebase';
import {
  collection, onSnapshot, orderBy, query, where, doc, getDoc,
  updateDoc, addDoc, serverTimestamp
} from 'firebase/firestore';

type Status = 'pending' | 'approved' | 'rejected' | 'in_progress' | 'delivered';
type UserRole = 'buyer' | 'supervisor' | 'procurement' | 'admin';

type Row = {
  id: string;
  orderNo?: string;
  date?: string;
  requesterName?: string;
  total?: number;
  status: Status | string;
  createdAt?: any;
};

export default function TrackingPage() {
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState('');
  const [role, setRole] = useState<UserRole>('buyer');

  const [rowsTracking, setRowsTracking] = useState<Row[]>([]);   // ตารางติดตาม (หลัก)
  const [rowsPending, setRowsPending]   = useState<Row[]>([]);   // คิวรออนุมัติ (เฉพาะ supervisor)
  const [savingId, setSavingId] = useState<string | null>(null);

  useEffect(() => {
    let offTracking: (() => void) | undefined;
    let offPending:  (() => void) | undefined;

    const offAuth = auth.onAuthStateChanged(async (u) => {
      if (!u) { window.location.href = '/login'; return; }

      // โหลด role
      let myRole: UserRole = 'buyer';
      try {
        const prof = await getDoc(doc(db, 'users', u.uid));
        const data = prof.data() as any | undefined;
        if (data?.role) myRole = data.role as UserRole;
      } catch {}
      setRole(myRole);

      // ตารางติดตาม (หลัก)
      const base = collection(db, 'orders');
      const qTracking =
        myRole === 'supervisor'
          ? query(base, orderBy('createdAt', 'desc')) // เห็นทั้งหมด
          : query(base, where('requesterUid', '==', u.uid), orderBy('createdAt', 'desc')); // ของตัวเอง

      offTracking?.();
      offTracking = onSnapshot(
        qTracking,
        (snap) => {
          const list = snap.docs.map((d) => {
            const data = d.data() as any;
            return {
              id: d.id,
              orderNo: data.orderNo || '',
              date: data.date || '',
              requesterName: data.requesterName || '',
              total: Number(data.total || 0),
              status: data.status || 'pending',
              createdAt: data.createdAt,
            } as Row;
          });
          setRowsTracking(list);
          setErr('');
          setLoading(false);
        },
        (e) => {
          setErr(String(e?.message || e));
          setLoading(false);
        }
      );

      // คิวรออนุมัติ (เฉพาะ supervisor)
      if (myRole === 'supervisor') {
        const qPending = query(base, where('status', '==', 'pending'), orderBy('createdAt', 'desc'));
        offPending?.();
        offPending = onSnapshot(
          qPending,
          (snap) => {
            const list = snap.docs.map((d) => {
              const data = d.data() as any;
              return {
                id: d.id,
                orderNo: data.orderNo || '',
                date: data.date || '',
                requesterName: data.requesterName || '',
                total: Number(data.total || 0),
                status: data.status || 'pending',
                createdAt: data.createdAt,
              } as Row;
            });
            setRowsPending(list);
          },
          (e) => setErr(String(e?.message || e))
        );
      } else {
        setRowsPending([]);
      }
    });

    return () => {
      offTracking?.();
      offPending?.();
      offAuth();
    };
  }, []);

  // actions
  const approve = async (r: Row) => {
    try {
      setSavingId(r.id);
      await updateDoc(doc(db, 'orders', r.id), {
        status: 'อนุมัติแล้ว',
        approvedByUid: auth.currentUser?.uid || null,
        approvedAt: serverTimestamp(),
      });
      await addDoc(collection(db, 'notifications'), {
        toRole: 'procurement',
        orderId: r.id,
        orderNo: r.orderNo || '',
        title: 'ใบสั่งซื้อได้รับอนุมัติ',
        message: `#${r.orderNo || ''} โดย ${r.requesterName || ''}`,
        kind: 'approved',
        read: false,
        createdAt: serverTimestamp(),
      });
    } catch (e:any) {
      alert(e.message || 'อนุมัติไม่สำเร็จ');
    } finally {
      setSavingId(null);
    }
  };

  const reject = async (r: Row) => {
    const reason = prompt('เหตุผลการไม่อนุมัติ (ใส่หรือเว้นว่างก็ได้)') || '';
    try {
      setSavingId(r.id);
      await updateDoc(doc(db, 'orders', r.id), {
        status: 'ไม่อนุมัติ',
        rejectedByUid: auth.currentUser?.uid || null,
        rejectedAt: serverTimestamp(),
        rejectReason: reason,
      });
      await addDoc(collection(db, 'notifications'), {
        toRole: 'procurement',
        orderId: r.id,
        orderNo: r.orderNo || '',
        title: 'ใบสั่งซื้อไม่ได้รับอนุมัติ',
        message: `#${r.orderNo || ''} โดย ${r.requesterName || ''}${reason ? ` (เหตุผล: ${reason})` : ''}`,
        kind: 'rejected',
        read: false,
        createdAt: serverTimestamp(),
      });
    } catch (e:any) {
      alert(e.message || 'ไม่อนุมัติไม่สำเร็จ');
    } finally {
      setSavingId(null);
    }
  };

  // render
  if (loading) return <div className="container-nice py-6">กำลังโหลด...</div>;

  return (
    <div className="container-nice py-6 space-y-8">
      {/* ตารางติดตาม (หลัก) */}
      <section>
        <h2 className="text-xl font-semibold mb-4">ติดตามสถานะใบสั่งซื้อ</h2>
        <div className="border rounded-2xl overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-slate-50">
              <tr className="text-left text-slate-600">
                <th className="px-3 py-2 w-28">เลขที่</th>
                <th className="px-3 py-2 w-44">วันที่สร้าง</th>
                <th className="px-3 py-2">ผู้สั่งซื้อ</th>
                <th className="px-3 py-2">วันที่เอกสาร</th>
                <th className="px-3 py-2 w-40 text-right">ยอดรวม (บาท)</th>
                <th className="px-3 py-2 w-44">สถานะ</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {rowsTracking.map((r) => (
                <tr
                  key={r.id}
                  className="border-t hover:bg-slate-50 cursor-pointer"
                  onClick={() => (location.href = `/orders/${r.id}`)}
                >
                  <td className="px-3 py-2 tabular-nums">{r.orderNo || '—'}</td>
                  <td className="px-3 py-2">
                    {r.createdAt?.toDate ? r.createdAt.toDate().toLocaleString('th-TH') : '—'}
                  </td>
                  <td className="px-3 py-2">{r.requesterName || '—'}</td>
                  <td className="px-3 py-2">{r.date || '—'}</td>
                  <td className="px-3 py-2 text-right tabular-nums">
                    {Number(r.total || 0).toLocaleString('th-TH')}
                  </td>
                  <td className="px-3 py-2">
                    <span className="inline-flex px-2 py-1 rounded bg-slate-100 text-slate-700">
                      {labelStatus(r.status)}
                    </span>
                  </td>
                </tr>
              ))}
              {rowsTracking.length === 0 && (
                <tr><td className="px-3 py-3 text-slate-500" colSpan={6}>ไม่มีข้อมูล</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      {/* คิวรออนุมัติ (เฉพาะ supervisor) */}
      {role === 'supervisor' && (
        <section>
          <h2 className="text-xl font-semibold mb-4">คิวรออนุมัติ</h2>
          <div className="border rounded-2xl overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-slate-50">
                <tr className="text-left text-slate-600">
                  <th className="px-3 py-2 w-28">เลขที่</th>
                  <th className="px-3 py-2 w-44">วันที่สร้าง</th>
                  <th className="px-3 py-2">ผู้สั่งซื้อ</th>
                  <th className="px-3 py-2">วันที่เอกสาร</th>
                  <th className="px-3 py-2 w-40 text-right">ยอดรวม (บาท)</th>
                  <th className="px-3 py-2 w-56 text-right">อนุมัติ</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {rowsPending.map((r) => (
                  <tr key={r.id} className="border-t">
                    <td className="px-3 py-2 tabular-nums">{r.orderNo || '—'}</td>
                    <td className="px-3 py-2">
                      {r.createdAt?.toDate ? r.createdAt.toDate().toLocaleString('th-TH') : '—'}
                    </td>
                    <td className="px-3 py-2">{r.requesterName || '—'}</td>
                    <td className="px-3 py-2">{r.date || '—'}</td>
                    <td className="px-3 py-2 text-right tabular-nums">
                      {Number(r.total || 0).toLocaleString('th-TH')}
                    </td>
                    <td className="px-3 py-2">
                      <div className="flex justify-end gap-2">
                        <button
                          type="button"
                          className="btn btn-success"
                          disabled={savingId === r.id}
                          onClick={() => approve(r)}
                        >
                          ✅ {savingId === r.id ? 'กำลังอนุมัติ...' : 'อนุมัติ'}
                        </button>
                        <button
                          type="button"
                          className="btn btn-danger"
                          disabled={savingId === r.id}
                          onClick={() => reject(r)}
                        >
                          ❌ {savingId === r.id ? 'กำลังทำรายการ...' : 'ไม่อนุมัติ'}
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
                {rowsPending.length === 0 && (
                  <tr><td className="px-3 py-3 text-slate-500" colSpan={6}>ไม่มีรายการรออนุมัติ</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </section>
      )}
    </div>
  );
}

function labelStatus(s: Status | string) {
  const x = String(s);
  if (x === 'pending' || x === 'รออนุมัติ') return 'รออนุมัติ';
  if (x === 'approved' || x === 'อนุมัติแล้ว') return 'อนุมัติแล้ว';
  if (x === 'rejected' || x === 'ไม่อนุมัติ') return 'ไม่อนุมัติ';
  if (x === 'in_progress' || x === 'กำลังจัดซื้อ') return 'กำลังจัดซื้อ';
  if (x === 'delivered' || x === 'รับของแล้ว') return 'รับของแล้ว';
  return x;
}
