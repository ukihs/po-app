import { initializeApp, getApp, getApps } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: import.meta.env.PUBLIC_FIREBASE_API_KEY,
  authDomain: import.meta.env.PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.PUBLIC_FIREBASE_APP_ID,
};

function getFirebaseApp() {
  if (getApps().length) return getApp();
  return initializeApp(firebaseConfig);
}

export const app = getFirebaseApp();

// เพิ่มสองบรรทัดนี้เพื่อให้ส่วนอื่นนำไปใช้ได้
export const auth = getAuth(app);
export const db = getFirestore(app);

// debug เล็กน้อยไว้เช็คใน browser console
if (typeof window !== 'undefined') {
  const ok = !!firebaseConfig.apiKey && firebaseConfig.apiKey?.startsWith('AIza');
  console.log('[Firebase TEST]', {
    projectId: firebaseConfig.projectId,
    authDomain: firebaseConfig.authDomain,
    hasApiKey: ok,
  });
}
